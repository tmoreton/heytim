"""The Stan factory: a preconfigured ``strands.Agent`` in one call."""

from __future__ import annotations

import json
import os
import re
import tempfile
from typing import Any

from strands import Agent
from strands.memory import MemoryManager, MemoryStore
from strands.models import Model, ModelRouter
from strands.session import SnapshotSessionManager
from strands.storage import LocalFileStorage
from strands.tools.mcp import MCPClient, MCPServerConfig
from strands.types.tools import AgentTool
from strands.vended_plugins.context_offloader import ContextOffloader, FileStorage
from strands.vended_plugins.skills import AgentSkills
from strands.vended_tools import shell

from strands_stan import defaults
from strands_stan.interventions import InterventionsOption, resolve_interventions
from strands_stan.memory import resolve_memory
from strands_stan.models import resolve_model, resolve_web_fetch_model
from strands_stan.plugins import EnvironmentContext, Todos
from strands_stan.prompt import build_system_prompt
from strands_stan.telemetry import setup_telemetry
from strands_stan.tools import edit, programmatic_tool_caller, read, web_fetch_tool, write
from strands_stan.tools.subagent import build_default_subagent

# Built-in tool names that toggle model behavior rather than adding a tool object. ``web_search``
# enables the provider's native web search in model resolution, so it is recognized here but never
# appears in the agent's tools list.
_VIRTUAL_BUILTIN_TOOLS = frozenset({"web_search"})

# Built-in plugins, each toggled by name via ``builtin_plugins``. Unlike the offloader and skills
# plugins (wired from their own options), these are opt-out feature plugins that only bundle a tool
# and a loop-level behavior; the map is the seam to grow the set (e.g. memories) later.
_BUILTIN_PLUGINS = {"todos": Todos, "environment": EnvironmentContext}

_AUTO_MAX_RESULT_TOKENS = 1_500
_AUTO_PREVIEW_TOKENS = 750

# Sentinel for ``caching``: distinguishes "not passed" (the default, which warns on an unsupported
# provider) from an explicit value like ``caching=None`` (off) or ``caching="auto"`` (which raises).
_UNSET: Any = object()


def _sanitize_session_id(session_id: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "-", session_id.strip().lower()) or "default"


def _builtin_tools(parent_config: dict[str, Any]) -> dict[str, Any]:
    """The built-in tools by name. ``web_fetch`` and ``subagent`` are built here (not module
    constants) because they need config derived from the agent: ``web_fetch`` its summarizer model,
    ``subagent`` the whole parent config. ``subagent``'s own delegation-depth budget lives on
    ``agent.state``, tracked by the tool itself rather than here."""
    model, web_fetch_model = parent_config["model"], parent_config["web_fetch_model"]
    return {
        t.tool_name: t
        for t in (
            shell,
            read,
            write,
            edit,
            programmatic_tool_caller,
            web_fetch_tool(resolve_web_fetch_model(model, web_fetch_model)),
        )
    } | {"subagent": build_default_subagent(harness_agent, parent_config)}


def _select_builtin_tools(names: list[str] | tuple[str, ...], tools: dict[str, Any]) -> list[Any]:
    selected = []
    for name in names:
        if name in _VIRTUAL_BUILTIN_TOOLS:  # web_search is a model switch, never a tool object
            continue
        if name not in tools:
            available = ", ".join(sorted([*tools, *_VIRTUAL_BUILTIN_TOOLS]))
            raise ValueError(f"Unknown built-in tool {name!r}. Available: {available}.")
        selected.append(tools[name])
    return selected


def _durable_offloader(offload_dir: str) -> Any:
    return ContextOffloader(
        storage=FileStorage(offload_dir),
        max_result_tokens=_AUTO_MAX_RESULT_TOKENS,
        preview_tokens=_AUTO_PREVIEW_TOKENS,
    )


def _has_offloader(plugins: list[Any]) -> bool:
    return any(isinstance(p, ContextOffloader) for p in plugins)


def _skills_plugin(skills_dir: str | list[str]) -> Any | None:
    dirs = [skills_dir] if isinstance(skills_dir, str) else skills_dir
    existing = [d for d in dirs if os.path.isdir(d)]
    if not existing:
        return None
    return AgentSkills(skills=existing)


def _has_skills(plugins: list[Any]) -> bool:
    return any(isinstance(p, AgentSkills) for p in plugins)


def _select_builtin_plugins(names: list[str] | tuple[str, ...] | None, existing: list[Any]) -> list[Any]:
    if names is None:
        names = defaults.DEFAULT_BUILTIN_PLUGINS
    selected = []
    for name in names:
        if name not in _BUILTIN_PLUGINS:
            available = ", ".join(sorted(_BUILTIN_PLUGINS))
            raise ValueError(f"Unknown built-in plugin {name!r}. Available: {available}.")
        plugin_cls = _BUILTIN_PLUGINS[name]
        if not any(isinstance(p, plugin_cls) for p in existing):
            selected.append(plugin_cls())
    return selected


def _check_name_collisions(*sources: tuple[str, bool, list[Any]]) -> None:
    """Raise if two tools would register under the same name, so a collision fails at construction
    with the losing source named rather than one tool silently disappearing. Names differing only by
    ``-``/``_`` collide, matching the SDK tool registry. Each source is ``(label, is_builtin, tools)``;
    the remedy only mentions dropping a built-in when a built-in is actually one of the two sources."""
    seen: dict[str, tuple[str, bool]] = {}
    for label, is_builtin, tools in sources:
        for tool in tools:
            # Only resolved tool objects have a fixed name here; the SDK also accepts strings, dicts,
            # modules, and nested lists in ``tools`` and resolves them later, so skip those.
            if not isinstance(tool, AgentTool):
                continue
            key = tool.tool_name.replace("-", "_")
            if key in seen:
                prior_label, prior_builtin = seen[key]
                where = label if prior_label == label else f"{prior_label} and {label}"
                if is_builtin or prior_builtin:
                    remedy = "Rename the tool you passed, or drop the built-in via builtin_tools / builtin_plugins."
                else:
                    remedy = "Rename one so each tool has a unique name."
                raise ValueError(f"Tool name {tool.tool_name!r} is registered more than once (from {where}). {remedy}")
            seen[key] = (label, is_builtin)


def _plugin_tools(plugins: list[Any]) -> list[Any]:
    """The tools each plugin vends (e.g. the todos plugin's ``todo_write``), via the SDK's ``.tools``."""
    return [tool for plugin in plugins for tool in (getattr(plugin, "tools", None) or [])]


def _load_mcp_clients(mcp_servers: str | dict[str, MCPServerConfig]) -> list[MCPClient]:
    """Build MCP clients from a standard ``mcpServers`` config (a JSON file path or the mapping
    itself, optionally nested under an ``mcpServers`` key). The SDK connects each client, discovers
    its tools, and manages its lifecycle once passed to the agent.

    Each server defaults to ``continue_on_error`` so one that fails to start yields no tools instead
    of taking the agent down, and to a ``prefix`` of its own name so tools are namespaced as
    ``<server>_<tool>`` and two servers exposing the same tool (e.g. ``search``) don't clash. An
    explicit per-server value overrides either default; ``"prefix": ""`` opts a server out.
    """
    if isinstance(mcp_servers, str):
        with open(os.path.expanduser(mcp_servers)) as f:
            mcp_servers = json.load(f)
    servers = mcp_servers.get("mcpServers", mcp_servers) if isinstance(mcp_servers, dict) else mcp_servers
    if not isinstance(servers, dict):
        raise ValueError("MCP config must map server names to configs, optionally nested under an 'mcpServers' key.")
    # TODO: drop this prefix injection once the SDK's load_servers grows a prefix_with_server_name flag.
    resilient = {
        name: {"continue_on_error": True, "prefix": name, **entry} if isinstance(entry, dict) else entry
        for name, entry in servers.items()
    }
    return MCPClient.load_servers(resilient)


def harness_agent(
    *,
    model: Model | ModelRouter | str | None = None,
    thinking: str | bool | None = defaults.DEFAULT_THINKING,
    instructions: str | None = None,
    tools: list[Any] | None = None,
    mcp_servers: str | dict[str, MCPServerConfig] | None = None,
    builtin_tools: list[str] | None = None,
    web_fetch_model: Model | ModelRouter | str | None = None,
    caching: str | bool | None = _UNSET,
    context_management: str | bool | None = defaults.DEFAULT_CONTEXT_MANAGEMENT,
    session_id: str | None = None,
    session_dir: str = defaults.DEFAULT_SESSION_DIR,
    skills_dir: str | list[str] | None = defaults.DEFAULT_SKILLS_DIR,
    memory: str | bool | None = defaults.DEFAULT_MEMORY,
    memory_dir: str = defaults.DEFAULT_MEMORY_DIR,
    memory_store: MemoryStore | list[MemoryStore] | None = None,
    builtin_plugins: list[str] | None = None,
    interventions: InterventionsOption = None,
    **agent_kwargs: Any,
) -> Agent:
    """Build a preconfigured Strands agent with Stan's defaults enabled.

    Every default is overridable, and the return value is a plain ``strands.Agent`` that can
    be modified further after construction. Any keyword accepted by ``Agent`` may be passed
    through ``agent_kwargs``; an explicit ``agent_kwargs`` value takes precedence over the
    default it corresponds to.

    Args:
        model: A ``Model`` or ``ModelRouter`` instance, a ``"provider/name"`` string (e.g.
            ``"anthropic/claude-fable-5"``), a bare Bedrock model id, or ``None`` for the
            harness default (Bedrock Opus 4.8).
        thinking: Reasoning effort applied to the resolved model, mapped to each provider's
            request fields. ``"auto"`` (or ``True``, the default) uses the provider's
            recommended level, ``"low"``/``"medium"``/``"high"`` set it explicitly, and
            ``None``/``False`` leave the provider defaults untouched. Ignored when ``model``
            is a ``Model`` or ``ModelRouter`` instance.
        instructions: A domain block appended after the harness contract. Ignored when a full
            ``system_prompt`` is passed via ``agent_kwargs``.
        tools: Consumer tools, added alongside the built-in tools. To expose a specialist ``Agent``
            as a tool, wrap it with ``Agent.as_tool()`` and pass it here. A tool name must be unique
            across all sources (built-in tools, ``tools``, plugins); a collision raises at
            construction. To replace a built-in, drop it first via ``builtin_tools`` so the name is
            free.
        mcp_servers: MCP servers to connect, given as the standard ``mcpServers`` config: either a
            path to a JSON file or the mapping itself (a flat ``{name: {...}}`` map, or that map under
            an ``mcpServers`` key). Each server's tools are discovered and added to the tool list, and
            the SDK manages connection and lifecycle. A server that fails to start yields no tools
            rather than failing construction; set ``"continue_on_error": false`` on a server to make
            its failure fatal. Each server's tools are prefixed with its name by default
            (``<server>_<tool>``) so servers don't clash; set a server's ``"prefix"`` to override, or
            ``"prefix": ""`` to opt out.
        builtin_tools: Names of the built-in tools to enable. Defaults to
            ``["shell", "read", "write", "edit", "web_fetch", "web_search",
            "programmatic_tool_caller", "subagent"]``; pass ``[]`` to disable them. ``web_fetch``
            fetches a URL and answers a prompt about it via a small summarizer model, keeping the raw
            page out of the main context. ``web_search`` is not a tool but a switch: it turns on the
            model provider's native web search (OpenAI and Google), and is a no-op on providers
            without one (Bedrock, Anthropic) unless requested explicitly, which raises.
            ``programmatic_tool_caller`` lets the model orchestrate its other tools by writing Python
            code, returning only what the code prints (see its module for the security posture).
            ``subagent`` delegates a self-contained subtask to a child
            agent built through this same factory, so the child is a full harness member: it
            inherits the model, built-in tools, built-in plugins, skills, interventions, and the
            consumer ``plugins`` and ``hooks`` passed here (the gate and any policy plugins/hooks
            reach the delegate too), plus the consumer ``tools`` (narrowable — the delegate may be
            granted a subset). The plugin and hook *instances* are shared with the child, so one that
            keeps per-agent state must keep it in ``agent.state`` (the SDK convention), not on
            ``self``, or the child's construction will clobber the parent's. By default the model
            picks the ``generalist`` role, may write an ad-hoc role prompt, and may narrow the tool
            set (never widen it). Delegation depth is bounded, so a child eventually cannot delegate
            further. For a fully configured delegation tool (custom roles, model tiers, fixed
            prompts), build one with ``make_subagent`` and pass it via ``tools`` with ``subagent``
            dropped from ``builtin_tools``.
        web_fetch_model: Model the ``web_fetch`` summarizer runs on: a ``Model`` or ``ModelRouter``
            instance, a ``"provider/name"`` string, or ``None`` (the default) to use the small fast
            model for the main agent's provider so credentials align. A router uses its concrete
            default model. Ignored when ``web_fetch`` is not enabled.
        caching: Enables prompt caching to save cost and latency where the provider supports it
            (Bedrock and Anthropic direct set cache points and cached tools; OpenAI, Gemini, and
            bedrock-mantle cache automatically server-side). Defaults to on. ``False``/``None`` turns
            off what Stan configures, and has no effect where caching is automatic. Explicitly
            enabling caching on a pre-built ``Model`` instance raises (its provider is unknown); the
            default is ignored there (configure it on the instance).
        context_management: ``"auto"`` (or ``True``, the default) or ``"agentic"`` to enable
            SDK-managed context, or ``False``/``None`` to disable it. When enabled, large tool
            results are also offloaded to disk (a preview and reference are kept in context) so
            the agent can run longer before compacting; disabling turns this off too.
        session_id: When set, persists and rehydrates the conversation via a
            ``SnapshotSessionManager``. Offloaded artifacts are then kept under ``session_dir`` and
            stay durable across restarts; without a session they go to a temporary directory that
            does not outlive the process.
        session_dir: Root directory for session state and, when a session is active, offloaded
            artifacts.
        skills_dir: One directory, or a list of directories, scanned for Agent Skills (each a
            subdirectory with a ``SKILL.md``), loaded via the SDK's ``AgentSkills`` plugin for
            progressive disclosure. Defaults to ``"./.agent/skills"``; missing directories are
            skipped. Pass ``None`` (or an empty list) to disable.
        memory: File-backed long-term memory, on by default. Durable facts are distilled into
            markdown, searched, and injected on later turns. ``False`` or ``None`` disables it;
            an explicit ``memory_manager`` in ``agent_kwargs`` takes precedence.
        memory_dir: Directory for the default markdown memory store.
        memory_store: One memory store or a list of stores to manage instead of the default file
            store. The generalist shares these stores through a read-only manager.
        builtin_plugins: Names of the built-in feature plugins to enable. Defaults to
            ``["todos", "environment"]``: ``todos`` adds a ``todo_write`` tool that tracks
            multi-step work and re-surfaces the list before each step; ``environment`` injects the
            platform, date, working directory, and the project's ``AGENTS.md`` (plus links to nearby
            ``AGENTS.md``/``README.md`` files) before each user turn. Pass ``[]`` to disable them.
        memory: File-based long-term memory, on by default. When enabled, the agent distills durable
            facts into markdown files under ``memory_dir``, searches them before each turn, and
            folds the top matches into context. Persistence uses markdown files independent of any
            session, so memory survives across sessions. Extraction runs asynchronously every few
            turns on a small model to keep it cheap. ``False``/``None`` disables it. Ignored when an
            explicit ``memory_manager`` is passed. Extraction is background and turn-triggered, so a
            short run may end before the first extraction fires and the latest turns are unsaved when
            the agent responds. Run ``if agent.memory_manager: await agent.memory_manager.flush()`` at
            your shutdown boundary to persist what's pending.
        memory_dir: Directory the default memory store's files live in. Defaults to
            ``"./.agent/memory"``.
        memory_store: Swap the memory backend: one store or several, managed under Stan's memory
            policy (injection on, ``search_memory`` on, no ``add_memory`` tool) instead of the default
            file store. Use this for a non-file backend while keeping Stan's defaults; unlike a full
            ``memory_manager``, the ``subagent`` delegate can share these stores read-only. Ignored
            when ``memory`` is off or an explicit ``memory_manager`` is passed.
        interventions: Gate tool calls behind approval or a policy; defaults to ``None`` (off —
            every call runs). Accepts a preset (``"ask"`` approves every call, ``"smart"`` lets the
            SDK's LLM risk classifier flag risky ones), a natural-language policy used as that
            classifier's prompt, a ``.cedar`` policy file (needs ``strands-agents[cedar]``), a
            ``HumanInTheLoop``/``CedarAuthorization`` instance for full control, or a list layering a
            Cedar policy with one human gate. Sugar over the SDK's handlers; a ``subagent`` child
            inherits the policy so a delegate cannot bypass it.
    """
    setup_telemetry()

    selected_tools = builtin_tools if builtin_tools is not None else defaults.DEFAULT_BUILTIN_TOOLS
    web_search = "web_search" in selected_tools
    # Explicit when the caller passed builtin_tools themselves; otherwise it's on only by default.
    web_search_explicit = builtin_tools is not None

    caching_explicit = caching is not _UNSET
    caching_on = bool(defaults.DEFAULT_CACHING) if not caching_explicit else bool(caching)
    resolved_model = resolve_model(
        model,
        defaults.DEFAULT_MODEL,
        thinking,
        web_search=web_search,
        web_search_explicit=web_search_explicit,
        caching=caching_on,
        caching_explicit=caching_explicit,
    )

    if "system_prompt" not in agent_kwargs:
        agent_kwargs["system_prompt"] = build_system_prompt(instructions)

    # Consumer plugins and hooks are captured (not left in agent_kwargs) so they both build this
    # agent and reach subagent children, which must run under the same plugins, hooks, and gate.
    consumer_plugins = list(agent_kwargs.pop("plugins", None) or [])
    consumer_hooks = list(agent_kwargs.pop("hooks", None) or [])
    consumer = list(tools or [])
    memory_manager = agent_kwargs.pop("memory_manager", None)

    # The config a subagent child is rebuilt from (see build_default_subagent). Consumer ``tools`` are
    # forwarded (narrowable, gated by the inherited interventions); a custom ``memory_manager`` isn't,
    # so the delegate shares the parent's stores read-only or gets none. Depth rides on agent.state.
    parent_config = {
        "model": model,
        "thinking": thinking,
        "caching": caching,
        "context_management": context_management,
        "builtin_tools": builtin_tools,
        "web_fetch_model": web_fetch_model,
        "builtin_plugins": builtin_plugins,
        "skills_dir": skills_dir,
        "memory": False if memory_manager is not None else memory,
        "memory_dir": memory_dir,
        "memory_store": memory_store,
        "interventions": interventions,
        "plugins": consumer_plugins,
        "hooks": consumer_hooks,
        "tools": consumer,
    }

    builtin = _select_builtin_tools(selected_tools, _builtin_tools(parent_config))
    context_enabled = bool(context_management)
    if context_enabled and "conversation_manager" not in agent_kwargs:
        strategy = context_management if isinstance(context_management, str) else defaults.DEFAULT_CONTEXT_MANAGEMENT
        agent_kwargs["context_manager"] = strategy

    session_manager = agent_kwargs.pop("session_manager", None)
    if session_id and session_manager is None:
        session_manager = SnapshotSessionManager(
            _sanitize_session_id(session_id),
            storage=LocalFileStorage(session_dir),
        )

    # Assemble plugins before the collision check so plugin-vended tools are checked too; consumer
    # plugins stay first so the tail is Stan's own.
    plugins = list(consumer_plugins)

    if context_enabled and not _has_offloader(plugins):
        offload_dir = os.path.join(session_dir, "offloaded") if session_id else tempfile.mkdtemp(prefix="stan-offload-")
        plugins.append(_durable_offloader(offload_dir))

    if skills_dir and not _has_skills(plugins):
        skills = _skills_plugin(skills_dir)
        if skills is not None:
            plugins.append(skills)

    plugins.extend(_select_builtin_plugins(builtin_plugins, plugins))
    stan_plugins = plugins[len(consumer_plugins) :]

    # An explicit ``memory_manager`` wins; otherwise memory is built from ``memory``/``memory_store``
    # when on. A ``MemoryManager`` instance already carries its resolved tools (``search_memory`` by
    # default); a bare config does not, so only an instance can be pre-flighted for name collisions here.
    if memory and memory_manager is None:
        memory_manager = resolve_memory(
            stores=memory_store, model=model, memory_dir=memory_dir, web_fetch_model=web_fetch_model
        )
    memory_tools = memory_manager.tools if isinstance(memory_manager, MemoryManager) else []

    _check_name_collisions(
        ("a built-in tool", True, builtin),
        ("tools", False, consumer),
        ("a built-in plugin", True, _plugin_tools(stan_plugins)),
        ("plugins", False, _plugin_tools(consumer_plugins)),
        ("memory", True, memory_tools),
    )
    # MCP clients are tool providers, not tools; the SDK connects them and discovers their tool names
    # at load time, so they're appended after the name-collision pre-flight (which inspects resolved
    # tools only). Tools are namespaced by server (see _load_mcp_clients) so cross-server names don't
    # clash, but a server keyed to a built-in name (e.g. ``web`` exposing ``fetch`` -> ``web_fetch``) still can.
    mcp_clients = _load_mcp_clients(mcp_servers) if mcp_servers else []
    agent_tools = [*builtin, *consumer, *mcp_clients]

    return Agent(
        model=resolved_model,
        tools=agent_tools,
        plugins=plugins,
        hooks=consumer_hooks,
        session_manager=session_manager,
        memory_manager=memory_manager,
        interventions=resolve_interventions(interventions),
        **agent_kwargs,
    )
