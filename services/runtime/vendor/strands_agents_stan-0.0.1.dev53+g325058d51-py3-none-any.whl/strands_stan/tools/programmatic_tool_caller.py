"""``programmatic_tool_caller``: let the agent orchestrate its other tools with Python code.

The model calls this tool with a ``code`` string; the code runs in-process with every other
registered tool exposed as an ``async`` function, so the model can chain, loop over, filter, and
parallelize tool calls in a single turn instead of one tool call per model round-trip. Only text
the code sends to ``print()`` is returned to the model; a tool's return value stays in the code's
local scope unless printed, which keeps large intermediate payloads out of the context window.

Security posture: the code runs in the host process. The execution namespace is restricted --
dangerous builtins (``open``, ``exec``, ``eval``, ``compile``, ``__import__``, and similar) are
removed and ``import`` is limited to an allow-list of data-processing modules (``_ALLOWED_IMPORTS``)
so the naive reach for ``os``/``subprocess``/``socket`` fails. This is **hardening, not a sandbox**,
and the allow-list is explicitly not a capability boundary: restricting a Python namespace never is
(an allowed pure-Python module can re-export ``sys`` as an attribute, and code can reach interpreter
internals through the object graph). For a real boundary, run the whole agent under a Docker/SSH
sandbox.

Interventions still apply to the tool calls the code makes: inner calls run through the agent's
normal executor, so an autonomous policy (Cedar, a natural-language risk policy) that denies a call
blocks it and the code sees a catchable exception. Interrupt-based human approval cannot prompt
from inside a direct call, so a call gated that way raises a catchable error instead of pausing.
"""

from __future__ import annotations

import ast
import asyncio
import builtins as _builtins
import contextlib
import io
import json
import logging
import re
import traceback
import types
from collections.abc import Awaitable, Callable
from typing import Any

from strands.tools.decorator import tool
from strands.types.tools import ToolContext

logger = logging.getLogger(__name__)

# Data-processing modules the code may import. Capability modules (os, sys, subprocess, socket,
# shutil, pathlib, importlib, io, pickle, ...) are excluded so the naive ``import os`` fails. This is
# defense-in-depth, not a capability boundary: several of these transitively expose ``sys`` as an
# attribute, so a determined caller can still reach it -- see the module docstring. ``asyncio`` is
# intentionally absent too: the code gets a narrow facade (``_ASYNCIO_FACADE``), not the full module,
# which would re-expose subprocess and socket entry points by name.
_ALLOWED_IMPORTS = frozenset(
    {
        "json",
        "re",
        "math",
        "statistics",
        "datetime",
        "itertools",
        "collections",
        "functools",
        "operator",
        "textwrap",
        "base64",
        "hashlib",
        "decimal",
        "fractions",
        "string",
        "typing",
        "enum",
    }
)

# Builtins removed from the execution namespace: code execution, filesystem, and interactive entry
# points. ``__import__`` is replaced (not merely removed) with an allow-list-guarded version.
_BLOCKED_BUILTINS = frozenset({"open", "exec", "eval", "compile", "input", "breakpoint", "help", "__import__"})

# Names the injected tools must not shadow: ``asyncio`` is always available, ``print`` is replaced
# with an output-capturing version, ``__builtins__`` holds the restricted builtins, and ``__name__``
# is the base namespace key.
_RESERVED_NAMESPACE_NAMES = frozenset({"asyncio", "__builtins__", "__name__", "print"})

# The only ``asyncio`` surface exposed to the code, injected under the name ``asyncio`` (the full
# module is withheld and not importable). Limiting it to orchestration helpers keeps the naive path
# from reaching ``asyncio.create_subprocess_shell``/``open_connection`` and similar by name.
_ASYNCIO_FACADE = types.SimpleNamespace(
    gather=asyncio.gather,
    sleep=asyncio.sleep,
    wait_for=asyncio.wait_for,
    as_completed=asyncio.as_completed,
    TimeoutError=asyncio.TimeoutError,
)

_USER_CODE_FILENAME = "<programmatic_tool_caller>"

# Cap on the text returned to the model; a runaway ``print`` should not blow up the context window.
_MAX_OUTPUT_CHARS = 50_000

# Wall-clock ceiling for the awaited code. Only code that awaits is bounded: synchronous code (a
# CPU-bound loop, say) runs to completion on the event-loop thread and this timeout cannot preempt
# it. Bounding synchronous code would need a real sandbox; the TS port's ``node:vm`` timeout does
# bound its synchronous loops, so this is a deliberate cross-language difference.
_DEFAULT_TIMEOUT = 300.0
_CANCEL_POLL_INTERVAL = 0.05


class _Cancelled(Exception):
    """Raised when the parent's cancel signal fires mid-execution (distinct from an external cancel)."""


async def _poll_cancel(cancel_signal: Any) -> None:
    while not cancel_signal.is_set():
        await asyncio.sleep(_CANCEL_POLL_INTERVAL)


async def _await_bounded(coro: Awaitable[Any], timeout: float | None, cancel_signal: Any) -> None:
    """Await ``coro`` until it finishes, ``timeout`` elapses, or ``cancel_signal`` fires; on the latter
    two the coroutine is cancelled (unwinding any in-flight tool ``await``) before raising."""
    task = asyncio.ensure_future(coro)
    watch = asyncio.ensure_future(_poll_cancel(cancel_signal)) if cancel_signal is not None else None
    waiters = {task} | ({watch} if watch is not None else set())
    try:
        done, _ = await asyncio.wait(waiters, timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
        if task in done:
            task.result()
            return
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        if watch is not None and watch in done:
            raise _Cancelled
        raise asyncio.TimeoutError
    finally:
        # asyncio.wait leaves its children running if the wait itself is cancelled; cancel both so an
        # external cancel can't orphan the user coroutine (which could keep issuing tool calls detached).
        for pending in (task, watch):
            if pending is not None and not pending.done():
                pending.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await pending


# The module list is derived from ``_ALLOWED_IMPORTS`` so the model always sees exactly what it can
# import, with no second copy to keep in sync.
DEFAULT_PROGRAMMATIC_TOOL_CALLER_DESCRIPTION = (
    "Execute Python code that orchestrates the agent's other tools, each exposed as an async "
    'function -- always `await` them, e.g. `result = await read(path="/etc/hosts")`. The code runs '
    "in an async context, so `await` and `asyncio.gather(...)` work without boilerplate. You may "
    f"import these standard-library modules: {', '.join(sorted(_ALLOWED_IMPORTS))}; filesystem, "
    "network, and subprocess modules are not available -- use the agent's tools for those. Only text "
    "sent to `print()` is returned to you: a tool's return value stays in the code's local scope "
    "unless you print it, and a tool that fails raises an exception you can catch with try/except. "
    "A tool whose name is not a valid Python identifier (for example `fetch-url` or `ns.fetch`) is "
    "also available with those characters replaced by underscores (`fetch_url`, `ns_fetch`). Use "
    "this to chain, loop over, filter, or parallelize tool calls in a single turn instead of one "
    "tool call per model round-trip, keeping large intermediate results out of the conversation."
)


def _error_result(message: str) -> dict[str, Any]:
    return {"status": "error", "content": [{"text": message}]}


def _make_capturing_print(buffer: io.StringIO) -> Callable[..., None]:
    """Return a ``print`` replacement that writes to ``buffer`` by default.

    Injecting this captures the code's own ``print()`` output without touching the process-global
    ``sys.stdout`` (which would also capture unrelated concurrent output). A caller that passes an
    explicit ``file=`` still overrides the destination.
    """

    def capturing_print(*args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("file", buffer)
        print(*args, **kwargs)

    return capturing_print


def _make_guarded_import() -> Callable[..., Any]:
    """Return an ``__import__`` that permits only the allow-listed top-level modules."""
    real_import = _builtins.__import__

    def guarded_import(name: str, globals: Any = None, locals: Any = None, fromlist: Any = (), level: int = 0) -> Any:
        root = name.partition(".")[0]
        if level != 0 or root not in _ALLOWED_IMPORTS:
            allowed = ", ".join(sorted(_ALLOWED_IMPORTS))
            raise ImportError(f"import of {name!r} is not allowed here; allowed modules: {allowed}")
        return real_import(name, globals, locals, fromlist, level)

    return guarded_import


def _restricted_builtins() -> dict[str, Any]:
    """The builtins exposed to the code: the standard set minus ``_BLOCKED_BUILTINS``, with a
    guarded ``__import__``."""
    safe = {name: getattr(_builtins, name) for name in dir(_builtins) if name not in _BLOCKED_BUILTINS}
    safe["__import__"] = _make_guarded_import()
    return safe


def _execute_tool(agent: Any, tool_name: str, tool_input: dict[str, Any]) -> Any:
    """Invoke a tool through the agent and unwrap its result for the code.

    Calls ``agent.tool.<tool_name>`` with ``record_direct_tool_call=False`` so orchestration does
    not pollute the agent's message history. A successful result's ``text``/``json`` blocks are
    joined into a single string (empty when there are none); an error result is raised as a
    ``RuntimeError`` so it propagates like a normal exception in the code.
    """
    try:
        tool_caller = getattr(agent.tool, tool_name)
        result = tool_caller(record_direct_tool_call=False, **tool_input)
    except Exception as error:
        raise RuntimeError(f"Failed to execute tool '{tool_name}': {error}") from error

    if not isinstance(result, dict):
        return result

    if result.get("status") == "error":
        first = (result.get("content") or [{}])[0]
        error_text = first.get("text", "Unknown error") if isinstance(first, dict) else "Unknown error"
        raise RuntimeError(f"Tool '{tool_name}' error: {error_text}")

    parts = []
    for block in result.get("content", []):
        if not isinstance(block, dict):
            continue
        if "text" in block:
            parts.append(block["text"])
        elif "json" in block:
            parts.append(json.dumps(block["json"]))
    return "\n".join(parts)


def _make_async_tool_function(agent: Any, tool_name: str) -> Callable[..., Awaitable[Any]]:
    """Wrap a tool as an ``async`` callable for the execution namespace.

    The underlying direct tool call is blocking, so it is offloaded to a worker thread; this keeps
    the event loop free and lets the code parallelize calls with ``asyncio.gather(...)``.
    """

    async def tool_function(**kwargs: Any) -> Any:
        return await asyncio.to_thread(_execute_tool, agent, tool_name, kwargs)

    return tool_function


def _resolve_available_tools(agent: Any, allowed_tools: list[str] | None, self_name: str) -> set[str]:
    """Determine which tools to expose to the code. The caller never exposes itself. With
    ``allowed_tools`` set, the exposed set is the intersection with the registered tools (names not
    registered are ignored and logged, since a tool may be registered after the caller is created).
    """
    registered = set(agent.tool_registry.registry.keys()) - {self_name}
    if allowed_tools is None:
        return registered

    available = registered & set(allowed_tools)
    dropped = set(allowed_tools) - registered
    if dropped:
        logger.debug("dropped=<%s> | allowed_tools entries are not registered and were ignored", sorted(dropped))
    return available


def _identifier_alias(tool_name: str) -> str | None:
    """Return a valid-identifier alias for a tool name, or ``None`` if not applicable.

    Tool registries admit names that are not valid Python identifiers (MCP servers commonly use
    ``-`` or ``.``), which the code could not call by name. Such names get an alias with every
    non-word character replaced by ``_``, matching how ``agent.tool.<name>`` resolves underscore
    forms to hyphenated tools.
    """
    if tool_name.isidentifier():
        return None
    alias = re.sub(r"\W", "_", tool_name)
    return alias if alias.isidentifier() else None


def _build_namespace(available_tools: set[str], agent: Any) -> dict[str, Any]:
    """Build the code execution namespace: restricted builtins, ``asyncio``, and tool functions.

    A tool whose name is not a valid Python identifier is also injected under a normalized alias
    (see ``_identifier_alias``); an alias is skipped when it would shadow a reserved name, a
    real tool name, or another tool's alias.

    Raises:
        ValueError: If a tool name collides with a reserved namespace entry, which would shadow it.
    """
    clashing_tools = available_tools & _RESERVED_NAMESPACE_NAMES
    if clashing_tools:
        raise ValueError(
            f"Tool name(s) {sorted(clashing_tools)} conflict with reserved namespace entries "
            f"{sorted(_RESERVED_NAMESPACE_NAMES)}. Rename the tool(s) or restrict the exposed set via allowed_tools."
        )

    namespace: dict[str, Any] = {
        "__name__": "__main__",
        "__builtins__": _restricted_builtins(),
        "asyncio": _ASYNCIO_FACADE,
    }
    for tool_name in available_tools:
        namespace[tool_name] = _make_async_tool_function(agent, tool_name)

    aliases: dict[str, str] = {}
    ambiguous: set[str] = set()
    for tool_name in sorted(available_tools):
        alias = _identifier_alias(tool_name)
        if alias is None:
            continue
        if alias in _RESERVED_NAMESPACE_NAMES or alias in available_tools:
            logger.debug(
                "alias=<%s>, tool_name=<%s> | alias is already taken by a reserved entry or another tool, "
                "no alias injected",
                alias,
                tool_name,
            )
            continue
        if alias in aliases:
            ambiguous.add(alias)
            continue
        aliases[alias] = tool_name

    for alias in ambiguous:
        del aliases[alias]
        logger.warning("alias=<%s> | multiple tools normalize to this name, no alias injected", alias)

    for alias, tool_name in aliases.items():
        namespace[alias] = namespace[tool_name]

    return namespace


def _finalize_output(buffer: io.StringIO) -> str:
    """Trim and cap the captured output for return to the model."""
    raw = buffer.getvalue()
    truncated = len(raw) > _MAX_OUTPUT_CHARS
    text = (raw[:_MAX_OUTPUT_CHARS] if truncated else raw).strip() or "(no output)"
    if truncated:
        text += f"\n[output truncated at {_MAX_OUTPUT_CHARS} characters]"
    return text


def make_programmatic_tool_caller(
    *,
    allowed_tools: list[str] | None = None,
    name: str = "programmatic_tool_caller",
    description: str = DEFAULT_PROGRAMMATIC_TOOL_CALLER_DESCRIPTION,
    timeout: float | None = _DEFAULT_TIMEOUT,
) -> Any:
    """Create a programmatic-tool-caller tool.

    The returned tool executes agent-authored Python code in which the agent's other tools are
    exposed as ``async`` functions (``await tool_name(...)``). Only ``print()`` output is returned.

    The code runs in the host process with a restricted namespace (see the module docstring): this
    is hardening, not a sandbox.

    Args:
        allowed_tools: Registry names of the tools to expose to the code. ``None`` (the default)
            exposes every other registered tool. The caller never exposes itself. This limits which
            tools are exposed by name; it is not a security boundary.
        name: Tool name. Defaults to ``"programmatic_tool_caller"``.
        description: Tool description shown to the model.
        timeout: Wall-clock ceiling in seconds for the awaited code, or ``None`` to disable it.

    Returns:
        A decorated tool that runs code with access to the agent's other tools.
    """
    resolved_allowed_tools = list(allowed_tools) if allowed_tools is not None else None

    @tool(name=name, description=description, context="tool_context")
    async def programmatic_tool_caller_tool(code: str, tool_context: ToolContext) -> dict[str, Any]:
        """Execute Python code with the agent's other tools as async functions.

        Args:
            code: Python code to execute. Use ``await tool_name(...)`` to call tools.
            tool_context: Injected by the framework. Not user-facing.

        Returns:
            A tool result whose text is the code's captured ``print()`` output on success, or the
            error/traceback on failure.
        """
        agent = tool_context.agent
        if agent is None:
            return _error_result("No agent available. The programmatic tool caller requires an agent context.")

        available_tools = _resolve_available_tools(agent, resolved_allowed_tools, name)

        try:
            exec_namespace = _build_namespace(available_tools, agent)
        except ValueError as error:
            return _error_result(str(error))

        # Compile with top-level-await support so the model can ``await`` tools directly. This avoids
        # wrapping/indenting the code (which would corrupt continuation lines inside string literals)
        # and keeps tracebacks pointing at the model's own line numbers.
        try:
            compiled = compile(code, _USER_CODE_FILENAME, "exec", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
        except SyntaxError:
            return _error_result(f"Syntax error:\n{traceback.format_exc()}")

        output_buffer = io.StringIO()
        exec_namespace["print"] = _make_capturing_print(output_buffer)

        try:
            # ``eval`` runs synchronous code inline and returns a coroutine only when the code
            # contains a top-level ``await``; running agent-authored code is this tool's purpose.
            maybe_coroutine = eval(compiled, exec_namespace)  # noqa: S307 - restricted namespace, documented posture
            if maybe_coroutine is not None:
                await _await_bounded(maybe_coroutine, timeout, tool_context.cancel_signal)
        except _Cancelled:
            return _error_result("Execution cancelled.")
        except asyncio.TimeoutError:
            return _error_result(f"Execution error: timed out after {timeout} seconds.")
        # SystemExit/KeyboardInterrupt raised by user code are caught so they do not tear down the host.
        except (SystemExit, KeyboardInterrupt) as error:
            return _error_result(f"Execution error: {type(error).__name__}: {error}")
        except Exception:
            return _error_result(f"Execution error:\n{traceback.format_exc()}")

        return {"status": "success", "content": [{"text": _finalize_output(output_buffer)}]}

    return programmatic_tool_caller_tool


programmatic_tool_caller = make_programmatic_tool_caller()
"""Default programmatic tool caller. Exposes every other registered tool."""
