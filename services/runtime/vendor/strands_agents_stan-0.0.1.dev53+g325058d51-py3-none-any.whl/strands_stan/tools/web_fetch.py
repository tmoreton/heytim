"""web_fetch: fetch a URL and answer a prompt about its content.

Fetches the URL, reduces it to text, and asks a small fast model to answer the prompt over that
content, returning the answer rather than the raw page so large payloads never reach the main
agent's context. The summarizer runs on the same provider as the main agent (see
``resolve_web_fetch_model`` in ``models.py``), so credentials always align.

Uses only the standard library for the fetch (no third-party HTTP dependency). Candidate to port
into the core SDK later; keep it minimal and SDK-idiomatic.
"""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from strands import Agent
from strands.models import Model
from strands.tools.decorator import tool

_HEADERS = {"User-Agent": "strands-agents-stan/1.0"}
_TIMEOUT = 30
_MAX_CHARS = 50_000
_CACHE_TTL_SECONDS = 15 * 60

_SUMMARIZER_PROMPT = (
    "You answer a request about a single fetched web page. Use only the provided content; if it "
    "does not contain the answer, say so plainly. Be concise and factual, and preserve concrete "
    "details (names, numbers, quotes, links) relevant to the request."
)


def _html_to_text(html: str) -> str:
    html = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", html)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    return text.strip()


def _fetch_text(url: str) -> tuple[str, str]:
    """Fetch ``url`` and reduce it to text. Returns ``(resolved_url, text)``; raises on failure."""
    if urlparse(url).scheme not in ("http", "https"):
        raise ValueError(f"web_fetch only supports http(s) URLs, got {url!r}.")
    with urlopen(Request(url, headers=_HEADERS), timeout=_TIMEOUT) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        raw = response.read().decode(charset, errors="replace")
        content_type = response.headers.get("Content-Type", "")
        resolved_url = response.geturl()
    text = _html_to_text(raw) if "html" in content_type.lower() else raw
    return resolved_url, text[:_MAX_CHARS]


def web_fetch_tool(model: Model) -> Any:
    """Build a ``web_fetch`` tool whose summarizer answers over the fetched page using ``model``."""
    cache: dict[str, tuple[float, str, str]] = {}

    @tool(name="web_fetch")
    async def web_fetch(url: str, prompt: str = "") -> str:
        """Fetch a URL and answer a prompt about its content.

        Performs an HTTP GET, reduces the response to text, and asks a small fast model to answer
        the prompt using only that content, returning the answer rather than the raw page so large
        pages do not flood the conversation. Fetched content is cached for 15 minutes, so repeated
        fetches of the same URL are fast while each prompt is answered fresh.

        Args:
            url: The http(s) URL to fetch.
            prompt: What to extract from or answer about the fetched content. Leave empty to get
                the whole page content back verbatim instead of a model-generated answer.
        """
        cached = cache.get(url)
        if cached and cached[0] > time.monotonic():
            resolved_url, text = cached[1], cached[2]
        else:
            try:
                resolved_url, text = await asyncio.to_thread(_fetch_text, url)
            except (HTTPError, URLError, ValueError) as exc:
                return f"Failed to fetch {url}: {exc}"
            cache[url] = (time.monotonic() + _CACHE_TTL_SECONDS, resolved_url, text)

        if not prompt.strip():
            return text

        summarizer = Agent(model=model, system_prompt=_SUMMARIZER_PROMPT, callback_handler=None)
        result = await summarizer.invoke_async(
            f"Fetched URL: {resolved_url}\n\nRequest: {prompt}\n\n--- Content ---\n{text}"
        )
        return str(result)

    return web_fetch
