"""Default configuration for Stan."""

DEFAULT_MODEL = "bedrock/global.anthropic.claude-opus-4-8"

DEFAULT_THINKING = "auto"

DEFAULT_CONTEXT_MANAGEMENT = "auto"

DEFAULT_CACHING = "auto"

DEFAULT_BUILTIN_TOOLS = (
    "shell",
    "read",
    "write",
    "edit",
    "web_fetch",
    "web_search",
    "programmatic_tool_caller",
    "subagent",
)

DEFAULT_BUILTIN_PLUGINS = ("todos", "environment")

DEFAULT_SUBAGENT_MAX_DEPTH = 2

DEFAULT_SESSION_DIR = "./.agent/sessions"

DEFAULT_SKILLS_DIR = "./.agent/skills"

DEFAULT_MEMORY = "auto"

DEFAULT_MEMORY_DIR = "./.agent/memory"
