"""Model resolution from ``provider/name`` strings, with per-provider thinking config.

Consumers pass a ready ``Model`` instance, a ``"provider/name"`` string, a bare Bedrock model
id, or ``None`` for the harness default. Every provider uses its real model ids directly. The
``thinking`` level is mapped to each provider's own request fields here, so the caller sets one
value regardless of provider.

Prompt caching is requested via ``caching`` and reaches the provider one of two ways: Stan
configures Bedrock and Anthropic direct (cache points plus cached tool definitions), while OpenAI,
Gemini, and bedrock-mantle cache automatically server-side (Gemini on models 2.5 and newer). Only a
pre-built ``Model`` instance can't be honored (its provider is unknown), so a warning is logged.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from typing import Any, NamedTuple

from strands.models import Model

from strands_stan import defaults

logger = logging.getLogger(__name__)

_ANTHROPIC_MAX_TOKENS = 32_000

# Claude's real max_tokens ceiling by tier, verified live against Bedrock Converse. Applied on
# Bedrock and Anthropic-direct only — other Bedrock-hosted model families aren't known to need
# this. Matched as a substring so any Bedrock region/vendor prefix in front of it doesn't matter.
_CLAUDE_MAX_TOKENS = {
    "claude-opus-": 128_000,
    "claude-sonnet-": 128_000,
    "claude-haiku-": 64_000,
    "claude-fable-": 128_000,
}


def _claude_max_tokens(model_id: str) -> int | None:
    return next((tokens for needle, tokens in _CLAUDE_MAX_TOKENS.items() if needle in model_id), None)


# Small, fast model per provider for the web_fetch summarizer. Keyed by the main agent's provider
# so the summarizer shares its credentials. Kept byte-identical with ``_WEB_FETCH_MODELS`` in the
# TypeScript ``models.ts``.
_WEB_FETCH_MODELS = {
    "bedrock": "global.anthropic.claude-haiku-4-5-20251001-v1:0",
    "bedrock-mantle": "openai.gpt-5.6-luna",
    "anthropic": "claude-haiku-4-5-20251001",
    "openai": "gpt-5.6-luna",
    "google": "gemini-3.5-flash",
}

# Cross-region inference profile prefixes stripped from a Bedrock model id before matching its
# provider family. Kept byte-identical with ``models.ts``.
_BEDROCK_REGION_PREFIXES = ("global.", "us.", "eu.", "au.", "jp.")


# Reasoning levels each provider's API accepts. Stan validates against the resolved
# provider's set so an unsupported level fails here rather than as a request error.
_ANTHROPIC_LEVELS = ("low", "medium", "high", "xhigh", "max")
_OPENAI_LEVELS = ("minimal", "low", "medium", "high", "xhigh", "none")
_BEDROCK_GPT_LEVELS = ("none", "low", "medium", "high", "xhigh", "max")
_BEDROCK_GPT_OSS_LEVELS = ("low", "medium", "high")
_BEDROCK_QWEN_LEVELS = ("none", "minimal", "low", "medium", "high", "xhigh", "max")
_GOOGLE_LEVELS = ("minimal", "low", "medium", "high")


def _claude_thinking(effort: str) -> dict:
    return {
        "thinking": {"type": "adaptive", "display": "summarized"},
        "output_config": {"effort": effort},
    }


def _bedrock_family(model_id: str) -> str:
    prefix = next((prefix for prefix in _BEDROCK_REGION_PREFIXES if model_id.startswith(prefix)), "")
    return model_id[len(prefix) :]


def _bedrock_effort(model_id: str, thinking: str | bool | None) -> str | None:
    family = _bedrock_family(model_id)
    if family.startswith("anthropic."):
        return _effort(thinking, "high", _ANTHROPIC_LEVELS)
    if family.startswith("openai.gpt-5.6-"):
        return _effort(thinking, "high", _BEDROCK_GPT_LEVELS)
    if family.startswith("openai.gpt-oss-"):
        return _effort(thinking, "high", _BEDROCK_GPT_OSS_LEVELS)
    if family.startswith("qwen."):
        return _effort(thinking, "high", _BEDROCK_QWEN_LEVELS)
    if thinking in (None, False, True, "auto"):
        return None
    raise ValueError(f"Thinking level {thinking!r} is not supported by Bedrock model {model_id}.")


def _bedrock_thinking(model_id: str, effort: str | None) -> dict | None:
    if effort is None:
        return None
    family = _bedrock_family(model_id)
    if family.startswith("anthropic."):
        return _claude_thinking(effort)
    if family.startswith("openai.gpt-5.6-"):
        return {"reasoning": {"effort": effort}}
    if family.startswith("openai.gpt-oss-"):
        return {"reasoning_effort": effort}
    if family.startswith("qwen."):
        return {"reasoning_effort": effort}
    return None


def _bedrock(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    from strands.models import BedrockModel, CacheConfig

    thinking = _bedrock_thinking(model_id, effort)
    extra: dict[str, Any] = {} if thinking is None else {"additional_request_fields": thinking}
    max_tokens = _claude_max_tokens(model_id)
    if max_tokens is not None:
        extra["max_tokens"] = max_tokens
    if caching:
        # The SDK injects cache points for Anthropic model ids on Bedrock (a no-op for others).
        # Tools are stable across turns, so cache them too.
        extra["cache_config"] = CacheConfig(strategy="auto")
        extra["cache_tools"] = "default"
    return BedrockModel(model_id=model_id, **extra)


def _anthropic(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    from strands.models import CacheConfig
    from strands.models.anthropic import AnthropicModel

    extra: dict[str, Any] = {} if effort is None else {"params": _claude_thinking(effort)}
    if caching:
        # Caches the tool definitions plus a cache point on the last user message; the system
        # prompt is cached automatically. Mirrors the Bedrock builder.
        extra["cache_config"] = CacheConfig(strategy="auto")
        extra["cache_tools"] = "default"
    max_tokens = _claude_max_tokens(model_id) or _ANTHROPIC_MAX_TOKENS
    return AnthropicModel(model_id=model_id, max_tokens=max_tokens, **extra)


def _openai(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    # ``caching`` is unused: OpenAI caches server-side with no opt-in.
    from strands.models.openai_responses import OpenAIResponsesModel

    params: dict[str, Any] = {}
    if effort is not None:
        params["reasoning"] = {"effort": effort}
    # The Responses API merges built-in tools carried in ``params`` with the agent's function tools.
    if web_search:
        params["tools"] = [{"type": "web_search"}]
    return OpenAIResponsesModel(model_id=model_id, **({"params": params} if params else {}))


def _bedrock_mantle(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    # ``web_search``/``caching`` are unused: Mantle has no documented native web_search tool, and it
    # caches server-side automatically over the OpenAI wire protocol it fronts (nothing to configure).
    from strands.models.openai_responses import BedrockMantleConfig, OpenAIResponsesModel

    params: dict[str, Any] = {} if effort is None else {"reasoning": {"effort": effort}}
    return OpenAIResponsesModel(
        model_id=model_id, bedrock_mantle_config=BedrockMantleConfig(), **({"params": params} if params else {})
    )


def _gemini(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    # ``caching`` is unused: Gemini caches implicitly server-side (models 2.5 and newer).
    from google.genai import types as genai_types
    from strands.models.gemini import GeminiModel

    extra: dict[str, Any] = {}
    if effort is not None:
        extra["params"] = {"thinking_config": {"thinking_level": effort}}
    # ``gemini_tools`` is appended alongside function declarations, so search coexists with tools.
    if web_search:
        extra["gemini_tools"] = [genai_types.Tool(google_search=genai_types.GoogleSearch())]
    return GeminiModel(model_id=model_id, **extra)


def _ollama(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    from strands.models.ollama import OllamaModel

    # OLLAMA_API_KEY mirrors the TS builder, which sends it as a bearer token (for proxied hosts).
    api_key = os.environ.get("OLLAMA_API_KEY")
    client_args = {"headers": {"Authorization": f"Bearer {api_key}"}} if api_key else None
    return OllamaModel(
        host=os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434"),
        ollama_client_args=client_args,
        model_id=model_id,
    )


def _litellm(model_id: str, effort: str | None, web_search: bool, caching: bool) -> Model:
    from strands.models.litellm import LiteLLMModel

    api_key = os.environ.get("LITELLM_API_KEY")
    api_base = os.environ.get("LITELLM_BASE_URL")
    client_args = {
        **({"api_key": api_key} if api_key else {}),
        **({"api_base": api_base} if api_base else {}),
    }
    return LiteLLMModel(client_args=client_args, model_id=model_id)


class Provider(NamedTuple):
    """How one model provider is built and what reasoning/search/caching it supports.

    ``web_search`` is enabled through model config on the providers whose SDK exposes a
    non-clobbering seam for it (OpenAI Responses ``params.tools``, Gemini ``gemini_tools``).
    Bedrock has no mechanism, and the Anthropic-direct model spreads ``params`` last so a
    ``tools`` key would overwrite the function tools; both stay ``False`` until the SDK grows a
    safe seam.

    ``caching`` marks providers where prompt caching is in effect when requested, whether or not
    Stan configures anything: Bedrock and Anthropic direct (Stan sets cache points and tool caching)
    plus OpenAI, Gemini, and bedrock-mantle (automatic server-side). Only a pre-built ``Model``
    instance can't be honored (its provider is unknown), so the factory warns there.
    """

    build: Callable[[str, str | None, bool, bool], Model]
    recommended_thinking: str | None
    thinking_levels: tuple[str, ...]
    web_search: bool
    caching: bool


_PROVIDERS = {
    "bedrock": Provider(_bedrock, "high", _ANTHROPIC_LEVELS, web_search=False, caching=True),
    "bedrock-mantle": Provider(_bedrock_mantle, "medium", _OPENAI_LEVELS, web_search=False, caching=True),
    "anthropic": Provider(_anthropic, "high", _ANTHROPIC_LEVELS, web_search=False, caching=True),
    "openai": Provider(_openai, "high", _OPENAI_LEVELS, web_search=True, caching=True),
    "google": Provider(_gemini, "medium", _GOOGLE_LEVELS, web_search=True, caching=True),
    "ollama": Provider(_ollama, None, (), web_search=False, caching=False),
    "litellm": Provider(_litellm, None, (), web_search=False, caching=False),
}


def _effort(thinking: str | bool | None, recommended: str | None, levels: tuple[str, ...]) -> str | None:
    if thinking in (None, False):
        return None
    if thinking is True or thinking == "auto":
        return recommended
    if thinking in levels:
        return thinking
    raise ValueError(
        f"Thinking level {thinking!r} is not supported by this provider. "
        f"Supported levels: {', '.join(levels)} (or 'auto', None)."
    )


def _split_provider(model: str) -> tuple[str, str]:
    """Split a ``"provider/name"`` string (or a bare Bedrock id) into ``(provider, name)``."""
    provider_name, sep, name = model.partition("/")
    if not sep:
        return "bedrock", model
    return provider_name, name


def _require_or_warn(explicit: bool, error: str, warning: str) -> None:
    """Raise ``error`` when a feature was requested explicitly but can't be honored; otherwise
    (the feature is on only by default) log ``warning`` and let the caller build without it."""
    if explicit:
        raise ValueError(error)
    logger.warning(warning)


def supports_web_search(model: Model | str | None) -> bool:
    """Whether native web search can be enabled for ``model``.

    A ``Model`` instance has an unknown provider, so this is ``False``; the caller configures
    search on the instance directly. ``None`` resolves to the default model.
    """
    if isinstance(model, Model):
        return False
    provider = _PROVIDERS.get(_split_provider(model or defaults.DEFAULT_MODEL)[0])
    return provider is not None and provider.web_search


def resolve_model(
    model: Model | str | None,
    default: str,
    thinking: str | bool | None,
    web_search: bool = False,
    web_search_explicit: bool = False,
    caching: bool = False,
    caching_explicit: bool = False,
) -> Model:
    """Resolve the ``model`` argument into a concrete ``Model`` instance.

    A passed-in ``Model`` instance is used verbatim; ``thinking`` does not apply to it.
    ``web_search`` and ``caching`` are handled the same way when the target can't honor them
    (a provider without the feature, or a pre-built ``Model`` instance): an explicit request
    (``web_search_explicit`` / ``caching_explicit``) raises, while the default is downgraded to a
    logged warning and the model is built without the feature.
    """
    if isinstance(model, Model):
        if web_search:
            _require_or_warn(
                web_search_explicit,
                "web_search cannot be enabled on a pre-built Model instance. Configure the "
                "provider's native web search on the instance, or drop 'web_search' from builtin_tools.",
                "web search not applied to a pre-built Model instance; configure it on the instance",
            )
        if caching:
            _require_or_warn(
                caching_explicit,
                "caching cannot be enabled on a pre-built Model instance. Configure prompt caching "
                "on the instance, or pass caching=False.",
                "prompt caching not applied to a pre-built Model instance; configure it on the instance",
            )
        return model
    if model is None:
        model = default

    provider_name, name = _split_provider(model)

    provider = _PROVIDERS.get(provider_name)
    if provider is None:
        supported = ", ".join(sorted(_PROVIDERS))
        raise ValueError(
            f"Unknown model provider {provider_name!r} in {model!r}. Supported providers: {supported}. "
            "Pass a strands.models.Model instance for anything else."
        )

    if web_search and not provider.web_search:
        supported = ", ".join(p for p, cfg in _PROVIDERS.items() if cfg.web_search)
        _require_or_warn(
            web_search_explicit,
            f"Provider {provider_name!r} does not support native web search. "
            f"Providers with web search: {supported}. Drop 'web_search' from builtin_tools, "
            "or switch to a supported provider.",
            f"provider=<{provider_name}> | native web search not supported by this provider; continuing without it",
        )
    if caching and not provider.caching:
        supported = ", ".join(p for p, cfg in _PROVIDERS.items() if cfg.caching)
        _require_or_warn(
            caching_explicit,
            f"Provider {provider_name!r} does not support prompt caching. "
            f"Providers with caching: {supported}. Pass caching=False, "
            "or switch to a supported provider.",
            f"provider=<{provider_name}> | prompt caching not supported by this provider; continuing without it",
        )
    effort = (
        _bedrock_effort(name, thinking)
        if provider_name == "bedrock"
        else _effort(thinking, provider.recommended_thinking, provider.thinking_levels)
    )
    return provider.build(name, effort, web_search and provider.web_search, caching and provider.caching)


def _bedrock_web_fetch_model(name: str) -> str | None:
    """Small Bedrock summarizer id for a Bedrock main model ``name``, or ``None`` if the family is
    unidentifiable.

    Bedrock hosts models from several providers, so the summarizer follows the main model's family.
    An Anthropic-on-Bedrock model (an ``anthropic.`` prefix, after any cross-region prefix like
    ``us.``) gets Anthropic Haiku; an OpenAI-on-Bedrock model (an ``openai.`` prefix) gets the OpenAI
    small model hosted on Bedrock (``openai.`` + the OpenAI-provider summarizer). Either way the
    summarizer shares the main model's provider. Any other family is unidentifiable and returns
    ``None`` so the caller can reuse the main model rather than guess.
    """
    family = _bedrock_family(name)
    if family.startswith("anthropic."):
        return _WEB_FETCH_MODELS["bedrock"]
    if family.startswith("openai."):
        return f"openai.{_WEB_FETCH_MODELS['openai']}"
    return None


def resolve_web_fetch_model(main_model: Model | str | None, web_fetch_model: Model | str | None) -> Model:
    """Resolve the model the web_fetch summarizer runs on.

    An explicit ``web_fetch_model`` (a ``Model`` instance or ``"provider/name"`` string) wins. With
    none set, pick the small fast model for the main agent's provider so the summarizer shares its
    credentials; when the main model is a ``Model`` instance (provider unknown), reuse it as the
    summarizer. On Bedrock the summarizer follows the main model's family (Anthropic-on-Bedrock gets
    Haiku, OpenAI-on-Bedrock gets the OpenAI small model); a Bedrock family we can't identify reuses
    the main model and logs a warning rather than guessing. Thinking is never applied: summarizing a
    page is a fast task.

    ``caching`` is deliberately not forwarded: the single message carries the per-call prompt before
    the page body, so every fetch would write a cache entry no later call can read.
    """
    if isinstance(web_fetch_model, Model):
        return web_fetch_model
    if web_fetch_model is not None:
        return resolve_model(web_fetch_model, web_fetch_model, thinking=None)

    if isinstance(main_model, Model):
        return main_model
    main = main_model if main_model is not None else defaults.DEFAULT_MODEL
    provider_name, name = _split_provider(main)
    if provider_name == "bedrock":
        small = _bedrock_web_fetch_model(name)
        if small is None:
            logger.warning(
                f"model=<{main}> | could not identify the Bedrock model family for the web_fetch "
                "summarizer; reusing the main model. Pass web_fetch_model to choose a smaller one."
            )
            return resolve_model(main, main, thinking=None)
    else:
        small = _WEB_FETCH_MODELS.get(provider_name)
    if small is None:
        if provider_name in ("ollama", "litellm"):
            logger.warning(
                f"model=<{main}> | no separate web_fetch summarizer is configured for provider "
                f"<{provider_name}>; reusing the main model. Pass web_fetch_model to choose another model."
            )
            return resolve_model(main, main, thinking=None)
        raise ValueError(
            f"No default web_fetch model for provider {provider_name!r}. "
            "Pass web_fetch_model explicitly, or disable web_fetch via builtin_tools."
        )
    return resolve_model(f"{provider_name}/{small}", small, thinking=None)
