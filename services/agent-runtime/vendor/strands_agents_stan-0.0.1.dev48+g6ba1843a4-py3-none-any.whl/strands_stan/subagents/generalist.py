"""generalist: a general-purpose delegate exposed as a tool.

The generalist is a full Stan agent that inherits the parent's configuration (model, thinking,
caching, context management, built-in tools, plugins, subagents, interventions, and sandbox), given
a domain-neutral role prompt instead of the parent's ``instructions``. Inheriting interventions and
sandbox is what stops a delegate from being an approval or isolation bypass. It runs in its own
fresh conversation and returns only its final answer, so a focused subtask (research, a multi-step
edit, an exploration) can run without its intermediate work piling up in the parent's context.

Built the custom-agent-tool way (a ``@tool`` whose callback constructs the agent) rather than via
``Agent.as_tool()``, which wraps an already-built instance. Constructing lazily inside the callback
means creating the tool builds nothing: a nested agent is only ever built if the model actually
calls it, so inheriting ``builtin_subagents`` (which includes ``generalist``) cannot recurse at
construction time. The ``build_agent`` factory (``harness_agent``) is injected rather than imported
for its value, so this module holds no import from ``agent.py``.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from strands.models import Model
from strands.tools.decorator import tool

from strands_stan.memory import resolve_memory

if TYPE_CHECKING:
    from strands import Agent
    from strands.memory import MemoryStore

    from strands_stan.interventions import InterventionsOption

GENERALIST_INSTRUCTIONS = (
    "You are a general-purpose subagent handling a focused subtask on behalf of a parent agent. "
    "You run in your own fresh conversation and cannot ask follow-up questions, so work from the "
    "task as given, make reasonable assumptions where it is underspecified, and see it through to "
    "a verified result. Return a self-contained answer: state what you did, what you found, and "
    "anything the parent needs to act on. Your final message is the only thing that returns to the "
    "parent, so put the substance there rather than in intermediate steps."
)


def build_generalist(
    build_agent: Callable[..., Agent],
    *,
    model: Model | str | None,
    thinking: str | bool | None,
    caching: Any,
    context_management: str | bool | None,
    builtin_tools: list[str] | None,
    web_fetch_model: Model | str | None,
    builtin_plugins: list[str] | None,
    builtin_subagents: list[str] | None,
    skills_dir: str | list[str] | None,
    memory: str | bool | None,
    memory_dir: str,
    memory_store: MemoryStore | list[MemoryStore] | None,
    interventions: InterventionsOption,
    sandbox: Any,
) -> Any:
    """Build a ``generalist`` tool that delegates a subtask to a fresh, parent-configured agent.

    ``build_agent`` is the ``harness_agent`` factory, injected to avoid importing ``agent.py``. The
    remaining arguments are the parent's configuration, forwarded so the delegate matches the parent
    in everything but its role prompt (generic, not the parent's ``instructions``) and sessions
    (none, so every call starts clean).
    """

    @tool(name="generalist")
    async def generalist(task: str) -> str:
        """Delegate a focused subtask to a general-purpose agent that runs in its own context.

        Reach for this when a subtask would otherwise flood your context with intermediate work
        (searching many files, a multi-step change, open-ended exploration) and you only need its
        conclusion. The delegate is as capable as you are but starts from a blank conversation: it
        sees nothing of this one, so put everything it needs into the task. It cannot come back with
        questions; it returns a single self-contained answer.

        Args:
            task: A complete, self-contained description of the subtask, including all context,
                file paths, constraints, and what to return. The delegate sees only this text.
        """
        # The delegate recalls the shared memory but must not write to it: extraction over a throwaway
        # subtask transcript would promote one-off task noise into the user's durable store, and a
        # second writable store over the same backend races the parent's on append. A recall-only
        # manager over the same store(s), injected explicitly, sidesteps both.
        memory_manager = (
            resolve_memory(
                stores=memory_store,
                model=model,
                memory_dir=memory_dir,
                web_fetch_model=web_fetch_model,
                writable=False,
            )
            if memory
            else None
        )
        agent = build_agent(
            model=model,
            thinking=thinking,
            caching=caching,
            context_management=context_management,
            builtin_tools=builtin_tools,
            web_fetch_model=web_fetch_model,
            builtin_plugins=builtin_plugins,
            builtin_subagents=builtin_subagents,
            skills_dir=skills_dir,
            memory=memory,
            memory_dir=memory_dir,
            memory_store=memory_store,
            memory_manager=memory_manager,
            interventions=interventions,
            sandbox=sandbox,
            instructions=GENERALIST_INSTRUCTIONS,
            callback_handler=None,
        )
        result = await agent.invoke_async(task)
        return str(result)

    return generalist
