"""Stan-authored built-in subagents.

Each built-in subagent is a general-capability delegate exposed to the agent as a tool, selected
by name via ``builtin_subagents``. Unlike consumer ``subagents`` (specific ``Agent`` instances the
consumer wires in), these are Stan-authored and inherit the parent's configuration. Keep them
minimal and SDK-idiomatic.
"""

from strands_stan.subagents.generalist import GENERALIST_INSTRUCTIONS, build_generalist

__all__ = ["GENERALIST_INSTRUCTIONS", "build_generalist"]
