"""Serializable Stan configuration shared with TypeScript and exported projects."""

from __future__ import annotations

import importlib
import importlib.util
import json
import logging
import math
import os
import re
from copy import deepcopy
from pathlib import Path
from types import ModuleType
from typing import Any

from strands_stan import defaults

logger = logging.getLogger(__name__)

DEFAULT_HARNESS_AGENT_CONFIG: dict[str, Any] = {
    "name": "Stan",
    "description": "",
    "instructions": "",
    "model": defaults.DEFAULT_MODEL,
    "modelModule": None,
    "thinking": "auto",
    "tools": [],
    "subagents": [],
    "mcpServers": {},
    "builtinTools": list(defaults.DEFAULT_BUILTIN_TOOLS),
    "webFetchModel": None,
    "webFetchModelModule": None,
    "caching": True,
    "contextManagement": defaults.DEFAULT_CONTEXT_MANAGEMENT,
    "sessionId": None,
    "sessionDir": defaults.DEFAULT_SESSION_DIR,
    "skillsDir": [defaults.DEFAULT_SKILLS_DIR],
    "memory": True,
    "memoryDir": defaults.DEFAULT_MEMORY_DIR,
    "memoryStores": [],
    "memoryManager": None,
    "plugins": [],
    "builtinPlugins": list(defaults.DEFAULT_BUILTIN_PLUGINS),
    "builtinSubagents": list(defaults.DEFAULT_BUILTIN_SUBAGENTS),
    "interventions": None,
    "interventionModules": [],
    "sandbox": None,
    "agentConfigModules": {},
    "dependencies": {"typescript": {}, "python": []},
    "agentConfig": {},
}


def define_harness_agent_config(config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Fill a partial portable config with Stan defaults."""
    return normalize_harness_agent_config({**deepcopy(DEFAULT_HARNESS_AGENT_CONFIG), **(config or {})})


def normalize_harness_agent_config(value: object) -> dict[str, Any]:
    """Validate and normalize a JSON-compatible Stan definition."""
    if not isinstance(value, dict):
        raise ValueError("Stan agent config must be an object.")
    unknown = sorted(set(value) - set(DEFAULT_HARNESS_AGENT_CONFIG))
    if unknown:
        logger.warning("Ignoring unknown Stan agent config keys: %s.", ", ".join(unknown))
    config = {
        **deepcopy(DEFAULT_HARNESS_AGENT_CONFIG),
        **{key: item for key, item in value.items() if key in DEFAULT_HARNESS_AGENT_CONFIG},
    }
    for key in ("name", "model", "sessionDir", "memoryDir"):
        if not isinstance(config[key], str) or not config[key].strip():
            raise ValueError(f"{key} must be a non-empty string.")
    for key in ("description", "instructions"):
        if not isinstance(config[key], str):
            raise ValueError(f"{key} must be a string.")
    _choice(config, "thinking", {"auto", "off", "minimal", "low", "medium", "high", "xhigh", "max"})
    _choice(config, "contextManagement", {"auto", "agentic", "off"})
    _string_list(config, "builtinTools")
    _string_list(config, "builtinPlugins")
    _string_list(config, "builtinSubagents")
    _allowed(config, "builtinTools", set(defaults.DEFAULT_BUILTIN_TOOLS))
    _allowed(config, "builtinPlugins", set(defaults.DEFAULT_BUILTIN_PLUGINS))
    _allowed(config, "builtinSubagents", set(defaults.DEFAULT_BUILTIN_SUBAGENTS))
    reference_kinds = {
        "tools": "tool",
        "subagents": "subagent",
        "plugins": "plugin",
        "memoryStores": "memory-store",
        "memoryManager": "memory-manager",
        "sandbox": "sandbox",
        "modelModule": "model",
        "webFetchModelModule": "model",
        "interventionModules": "intervention",
        "agentConfigModules": "agent-config",
    }
    for key in ("tools", "subagents", "plugins", "memoryStores"):
        config[key] = [_module_reference(item, reference_kinds[key]) for item in _list(config[key], key)]
    for key in ("memoryManager", "sandbox"):
        if config[key] is not None:
            config[key] = _module_reference(config[key], reference_kinds[key])
    for key in ("modelModule", "webFetchModelModule"):
        if config[key] is not None:
            config[key] = _module_reference(config[key], reference_kinds[key])
    config["interventionModules"] = [
        _module_reference(item, reference_kinds["interventionModules"])
        for item in _list(config["interventionModules"], "interventionModules")
    ]
    if not isinstance(config["agentConfigModules"], dict):
        raise ValueError("agentConfigModules must be an object.")
    config["agentConfigModules"] = {
        key: _module_reference(item, reference_kinds["agentConfigModules"])
        for key, item in config["agentConfigModules"].items()
    }
    if not isinstance(config["mcpServers"], (dict, str)) or (
        isinstance(config["mcpServers"], str) and not config["mcpServers"].strip()
    ):
        raise ValueError("mcpServers must be an object or non-empty file path.")
    if not isinstance(config["agentConfig"], dict):
        raise ValueError("agentConfig must be an object.")
    for key in ("caching", "memory"):
        if not isinstance(config[key], bool):
            raise ValueError(f"{key} must be a boolean.")
    for key in ("webFetchModel", "sessionId"):
        if config[key] is not None and not isinstance(config[key], str):
            raise ValueError(f"{key} must be a string or null.")
    if config["interventions"] is not None:
        if isinstance(config["interventions"], list):
            if any(not isinstance(item, str) or not item.strip() for item in config["interventions"]):
                raise ValueError("interventions must contain only non-empty strings.")
        elif not isinstance(config["interventions"], str):
            raise ValueError("interventions must be a string, array of strings, or null.")
    skills = config["skillsDir"]
    if skills is not None:
        config["skillsDir"] = _string_list(config, "skillsDir")
    dependencies = config["dependencies"]
    if not isinstance(dependencies, dict):
        raise ValueError("dependencies must be an object.")
    config["dependencies"] = dependencies = {
        "typescript": dependencies.get("typescript", {}),
        "python": dependencies.get("python", []),
    }
    if not isinstance(dependencies["typescript"], dict):
        raise ValueError("dependencies must contain a typescript object and python array.")
    if any(
        not isinstance(name, str) or not name.strip() or not isinstance(version, str) or not version.strip()
        for name, version in dependencies["typescript"].items()
    ):
        raise ValueError("dependencies.typescript must map package names to version strings.")
    _string_list(dependencies, "python")
    if any("\n" in item or "\r" in item for item in dependencies["python"]):
        raise ValueError("dependencies.python entries must not contain line breaks.")
    _assert_json_value(config)
    return deepcopy(config)


def harness_agent_kwargs_from_config(value: object, base_dir: str | Path = ".") -> dict[str, Any]:
    """Load executable references and convert portable config to ``harness_agent`` kwargs."""
    config = normalize_harness_agent_config(value)
    root = Path(base_dir).resolve()
    tools = _load_many(config["tools"], root)
    subagents = _load_many(config["subagents"], root, invoke=True)
    plugins = _load_many(config["plugins"], root)
    stores = _load_many(config["memoryStores"], root)
    memory_manager = _load_optional(config["memoryManager"], root)
    sandbox = _load_optional(config["sandbox"], root)
    model = _load_optional(config["modelModule"], root)
    web_fetch_model = _load_optional(config["webFetchModelModule"], root)
    interventions = _load_many(config["interventionModules"], root)
    agent_config_modules = {
        key: _load_reference(reference, root) for key, reference in config["agentConfigModules"].items()
    }
    kwargs = deepcopy(config["agentConfig"])
    kwargs.update(agent_config_modules)
    kwargs.update(
        {
            "name": config["name"],
            "model": config["model"] if model is None else model,
            "thinking": None if config["thinking"] == "off" else config["thinking"],
            "context_management": False if config["contextManagement"] == "off" else config["contextManagement"],
            "session_dir": _resolve_path(config["sessionDir"], root),
            "skills_dir": None
            if config["skillsDir"] is None
            else [_resolve_path(path, root) for path in config["skillsDir"]],
            "memory": "auto" if config["memory"] else False,
            "memory_dir": _resolve_path(config["memoryDir"], root),
        }
    )
    if config["builtinTools"] != list(defaults.DEFAULT_BUILTIN_TOOLS):
        kwargs["builtin_tools"] = config["builtinTools"]
    if not config["caching"]:
        kwargs["caching"] = False
    if config["builtinPlugins"] != list(defaults.DEFAULT_BUILTIN_PLUGINS):
        kwargs["builtin_plugins"] = config["builtinPlugins"]
    if config["builtinSubagents"] != list(defaults.DEFAULT_BUILTIN_SUBAGENTS):
        kwargs["builtin_subagents"] = config["builtinSubagents"]
    if config["description"]:
        kwargs["description"] = config["description"]
    if config["instructions"]:
        kwargs["instructions"] = config["instructions"]
    if tools:
        kwargs["tools"] = tools
    if subagents:
        kwargs["subagents"] = subagents
    if config["mcpServers"]:
        kwargs["mcp_servers"] = _python_mcp_servers(_expand_env(_mcp_server_map(config["mcpServers"], root)))
    if web_fetch_model is not None or config["webFetchModel"]:
        kwargs["web_fetch_model"] = config["webFetchModel"] if web_fetch_model is None else web_fetch_model
    if config["sessionId"]:
        kwargs["session_id"] = config["sessionId"]
    if stores:
        kwargs["memory_store"] = stores
    if memory_manager is not None:
        kwargs["memory_manager"] = memory_manager
    if plugins:
        kwargs["plugins"] = plugins
    configured_interventions = (
        config["interventions"]
        if isinstance(config["interventions"], list)
        else [config["interventions"]]
        if config["interventions"]
        else []
    )
    intervention_values = [*configured_interventions, *interventions]
    if intervention_values:
        kwargs["interventions"] = intervention_values[0] if len(intervention_values) == 1 else intervention_values
    if sandbox is not None:
        kwargs["sandbox"] = sandbox
    return kwargs


def _module_reference(value: object, kind: str) -> dict[str, Any]:
    if not isinstance(value, dict) or not isinstance(value.get("module"), str) or not value["module"].strip():
        raise ValueError(f"{kind} entries must contain a non-empty module.")
    if value.get("kind", kind) != kind:
        raise ValueError(f"Expected a {kind} reference.")
    if value.get("language") not in (None, "python", "typescript"):
        raise ValueError(f"{kind}.language must be python or typescript.")
    if value.get("files") is not None and (
        not isinstance(value["files"], list)
        or any(not isinstance(path, str) or not path.strip() for path in value["files"])
    ):
        raise ValueError(f"{kind}.files must contain non-empty strings.")
    if value.get("dependency") is not None and (
        not isinstance(value["dependency"], str) or not value["dependency"].strip()
    ):
        raise ValueError(f"{kind}.dependency must be a non-empty string.")
    result = deepcopy(value)
    result["kind"] = kind
    return result


def _load_many(references: list[dict[str, Any]], root: Path, *, invoke: bool = False) -> list[Any]:
    values: list[Any] = []
    for reference in references:
        value = _load_reference(reference, root)
        if invoke and callable(value):
            value = value()
        values.extend(value if isinstance(value, list) else [value])
    return values


def _load_optional(reference: dict[str, Any] | None, root: Path) -> Any:
    return None if reference is None else _load_reference(reference, root)


def _load_reference(reference: dict[str, Any], root: Path) -> Any:
    if reference.get("language") == "typescript" or Path(reference["module"]).suffix in {
        ".js",
        ".jsx",
        ".mjs",
        ".cjs",
        ".ts",
        ".tsx",
    }:
        raise ValueError(f"Cannot load TypeScript module {reference['module']!r} in the Python runtime.")
    module_name = reference["module"]
    module = _load_module(module_name, root)
    export = reference.get("export", "default")
    if export == "default" and not hasattr(module, "default"):
        export = "agent" if reference.get("kind") == "subagent" and hasattr(module, "agent") else export
    if not hasattr(module, export):
        raise ValueError(f"Module {module_name!r} does not export {export!r}.")
    return getattr(module, export)


def _load_module(module: str, root: Path) -> ModuleType:
    if module.startswith(".") or os.path.isabs(module):
        path = Path(_resolve_path(module, root))
        spec = importlib.util.spec_from_file_location(f"_stan_project_{abs(hash(path))}", path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Cannot load Python module {module!r}.")
        loaded = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(loaded)
        return loaded
    return importlib.import_module(module)


def _resolve_path(value: str, root: Path) -> str:
    path = Path(value).expanduser()
    return str(path if path.is_absolute() else root / path)


def _expand_env(value: Any) -> Any:
    if isinstance(value, str):

        def replace(match: re.Match[str]) -> str:
            name = match.group(1)
            resolved = os.environ.get(name)
            if resolved is None:
                raise ValueError(f"Environment variable {json.dumps(name)} is not set.")
            return resolved

        return re.sub(
            r"\$\{(?:env:)?([A-Za-z_][A-Za-z0-9_]*)\}",
            replace,
            value,
        )
    if isinstance(value, list):
        return [_expand_env(item) for item in value]
    if isinstance(value, dict):
        return {key: _expand_env(item) for key, item in value.items()}
    return value


def _python_mcp_servers(servers: dict[str, Any]) -> dict[str, Any]:
    renamed = {
        "continueOnError": "continue_on_error",
        "toolFilters": "tool_filters",
        "clientId": "client_id",
        "clientSecret": "client_secret",
    }

    def convert(value: Any) -> Any:
        if isinstance(value, list):
            return [convert(item) for item in value]
        if isinstance(value, dict):
            if "tasksConfig" in value:
                raise ValueError("Python Stan does not support MCP tasksConfig.")
            return {renamed.get(key, key): convert(item) for key, item in value.items()}
        return value

    return convert(servers)


def _mcp_server_map(value: dict[str, Any] | str, root: Path) -> dict[str, Any]:
    if isinstance(value, str):
        path = Path(_resolve_path(value, root))
        try:
            loaded = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError) as error:
            raise ValueError(f"MCP config {value!r} must be valid JSON.") from error
        if not isinstance(loaded, dict):
            raise ValueError(f"MCP config {value!r} must contain a server map.")
        value = loaded
    nested = value.get("mcpServers")
    if nested is None:
        return value
    if not isinstance(nested, dict):
        raise ValueError("mcpServers must contain a server map.")
    return nested


def _choice(config: dict[str, Any], key: str, choices: set[str]) -> None:
    if config[key] not in choices:
        raise ValueError(f"{key} must be one of: {', '.join(sorted(choices))}.")


def _list(value: object, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{label} must be an array.")
    return value


def _string_list(config: dict[str, Any], key: str) -> list[str]:
    value = _list(config[key], key)
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(f"{key} must contain only non-empty strings.")
    if len(set(value)) != len(value):
        raise ValueError(f"{key} must not contain duplicates.")
    return value


def _allowed(config: dict[str, Any], key: str, allowed: set[str]) -> None:
    unknown = set(config[key]) - allowed
    if unknown:
        raise ValueError(f"{key} contains unknown values: {', '.join(sorted(unknown))}.")


def _assert_json_value(value: Any) -> None:
    if value is None or isinstance(value, (str, bool)):
        return
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return
    if isinstance(value, list):
        for item in value:
            _assert_json_value(item)
        return
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        for item in value.values():
            _assert_json_value(item)
        return
    raise ValueError("Stan agent config must contain only JSON-compatible values.")
